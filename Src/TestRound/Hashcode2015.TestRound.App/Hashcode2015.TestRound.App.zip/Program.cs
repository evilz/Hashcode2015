﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Xml;
using Hashcode2015.TestRound.App.Model;
using Kunai.Extentions;

namespace Hashcode2015.TestRound.App
{
	class Program
	{
		static void Main(string[] args)
		{
			int R, C, H, S;
			using (var stream = File.OpenText(@"..\..\..\Input\test_round.in"))
			{
				//C: \Users\Vincent\Documents\GITHUB\Hashcode2015\Src\TestRound\Input\test_round.in
				var param = stream.ExtractValues<int>().ToArray();
				R = param[0];
				C = param[1];
				H = param[2];
				S = param[3];

				var matrix = stream.CreateMatrix<PizzaCell,char>(new Size(C,R), (y, x, val, self) => new PizzaCell(val));

				var parts = new List<PizzaPart>();
				PizzaPart part = null;
				for (int y	 = 0; y < R; y++)
				{
					var hamCount = 0;
					var cellCount = 0;
					for (int x = 0; x < C; x++)
					{
						cellCount++;

						if (part != null)
						{
							part.Cells.Add(matrix[y,x]);
							matrix[y, x].IsInPart = true;
						}

						if (matrix[y, x].IsHam)
						{
							hamCount++;

							switch (hamCount)
							{
								case 1:
									part = new PizzaPart {Start = new Point(x, y)};
									part.Cells.Add(matrix[y,x]);
									matrix[y, x].IsInPart = true;
									break;
								case 3:
									part.End = new Point(x,y);
									parts.Add(part);

									part = null;
									hamCount = 0;
									cellCount = 0;
									break;
								default:
									if(cellCount == S )
									{
										cellCount = 0;
										hamCount = 0;
									}
									break;
							}
						}
					}
				}

				Console.WriteLine(parts.Count);
				foreach (var p in parts)
				{
					Console.WriteLine("{0} {1} {2} {3}", p.Start.X,p.Start.Y,p.End.X,p.End.Y);
				}

				var totalUnsed = 0;
				var hamUnsed = 0;
				var otherUnsed = 0;
				var score = 0;
				matrix.ForEach((cell, point) => { if (!cell.IsInPart) totalUnsed++; });
				matrix.ForEach((cell, point) => { if (!cell.IsInPart && cell.IsHam) hamUnsed++; });
				matrix.ForEach((cell, point) => { if (!cell.IsInPart && !cell.IsHam) otherUnsed++; });
				matrix.ForEach((cell, point) => { if (cell.IsInPart) score++; });

			}

			

		}
	}
}
