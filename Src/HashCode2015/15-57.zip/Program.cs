﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using HashCode2015.Model;
using TrialRound.Extentions;


namespace HashCode2015
{
    class Program
    {
        static void Main(string[] args)
        {
            const string FILE_NAME = @"Samples/dc.in";
            //const string FILE_NAME = @"Samples/sample.in";


            var rowsCount = 0;
            var slotsCount = 0;
            var poolCount = 0;


            List<Server> servers;
            List<Point> deadSlots;
            
            ReadInputFile(FILE_NAME, ref rowsCount, ref slotsCount, ref poolCount,out deadSlots, out servers);




            var datacenter = new DataCenter(rowsCount, slotsCount, deadSlots, poolCount);

            datacenter.AddServers(servers);
            

           datacenter.DisplayGrid();
          //  datacenter.DisplayEmptySlot();
            
            Debug.Print(servers.Count(server => server.IsUsed).ToString());

            Console.ReadLine();
        }

        private static void ReadInputFile(string fileName, ref int rowsCount, ref int slotsCount, ref int poolCount,
            out List<Point> deadSlot,
            out List<Server> servers)
        {
            using (var inputStream = File.OpenRead(fileName))
            {
                var reader = new StreamReader(inputStream);

                // parse first line to get Matrix Size
                var inputInt = reader.ExtractValues<int>().ToArray();

                rowsCount = inputInt[0];
                slotsCount = inputInt[1];
                var slotUnavailableCount = inputInt[2];
                poolCount = inputInt[3];
                var serversCount = inputInt[4];

                deadSlot =
                    Enumerable.Range(0, slotUnavailableCount)
                        .Select(_ => reader.ExtractValues<int>().ToArray())
                        .Select(x => new Point(x[1], x[0]))
                        .ToList();

                servers =
                    Enumerable.Range(0, serversCount)
                        .Select(i => new {index = i, values = reader.ExtractValues<int>().ToArray()})
                        .Select(x => new Server(x.index, x.values[0], x.values[1]))
                        .ToList();
            }
        }
    }
}
