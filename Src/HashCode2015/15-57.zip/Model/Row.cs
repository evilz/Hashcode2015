﻿using System.Collections.Generic;
using System.Linq;
using HashCode2015.Extensions;

namespace HashCode2015.Model
{
    public class Row
    {
        private const int EMPTY_SLOT = -9;
        private const int DEAD_SLOT = -1;

        private readonly int _slotCount;
        private readonly int[] _rowGrid;
        private readonly List<Server> _servers;


        public int Index { get; set; }

        public Row(int index, int slotCount, IEnumerable<int> deadCell)
        {
            Index = index;
            _slotCount = slotCount;

            _rowGrid = new int[slotCount];
            Enumerable.Range(0,slotCount).ForEach(i => _rowGrid[i] = EMPTY_SLOT);
            
            _servers = new List<Server>();
            
            var deadCell1 = deadCell.ToList();
            deadCell1.ForEach(i => _rowGrid[i] = DEAD_SLOT);

        }

        private IEnumerable<Server> GetServersForPool(Pool pool)
        {
            return _servers.Where(s => s.Pool == pool);
        }

        public int GetCapacityForPool(Pool pool)
        {
            var capacity = GetServersForPool(pool).Sum(s => s.Capacity);
            return capacity;
        }


        // slot x, size
        public IEnumerable<RowSlot> AvailableSlot
        {
            get
            {
                var result = new List<RowSlot>();

                var slot = new RowSlot();

                for (var i = 0; i < _slotCount; i++)
                {
                    if (_rowGrid[i] == EMPTY_SLOT)
                    {
                        if (slot.IsNew())
                        {
                            slot.Position = i;
                            slot.Size = 0;
                        }
                        slot.Size++;
                    }
                    else
                    {
                        if (!slot.IsNew()) // end of slot
                        {
                            result.Add(slot);
                            slot = new RowSlot();
                        }
                    }
                }
                return result;
            }
        }


        public bool TryAddServer(Server server)
        {
            var slot = AvailableSlot.FirstOrDefault(a => a.Size >= server.Size);
            if (slot != null)
            {
                server.Slot = slot.Position;
                server.Row = Index;
                server.IsUsed = true;
                _servers.Add(server);

                for (int i = server.Slot; i < server.Slot + server.Size; i++)
                {
                    _rowGrid[i] = server.Index;
                }
            }
            else
            {
                server.IsUsed = false;
            }

            return server.IsUsed;
        }

    }
}


