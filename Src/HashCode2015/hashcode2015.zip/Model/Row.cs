﻿using System.Collections.Generic;
using System.Linq;

namespace HashCode2015.Model
{
    public class Row
    {
        public const int EMPTY_SLOT = -9;
        public const int DEAD_SLOT = -1;

        private readonly int _slotCount;
        private readonly int[] _rowGrid;

        public int Index { get; private set; }

        public Row(int index, int slotCount, List<int> deadCell)
        {
            Index = index;
            _slotCount = slotCount;
            _rowGrid = new int[slotCount];
            for (int i = 0; i < slotCount; i++)
            {
                _rowGrid[i] = EMPTY_SLOT; // EMPTY
            }

            Servers = new List<Server>();
            DeadCell = deadCell;
            foreach (var i in deadCell)
            {
                _rowGrid[i] = DEAD_SLOT;
            }


        }

        public List<Server> Servers { get; set; }
        public List<int> DeadCell { get; set; }

        public IEnumerable<Server> GetServersForPool(Pool pool)
        {
            return Servers.Where(s => s.Pool == pool);
        }

        public int GetCapacityForPool(Pool pool)
        {
            var capacity = GetServersForPool(pool).Sum(s => s.Capacity);
            return capacity;
        }


        // slot x, size
        public List<RowSlot> AvailableSlot
        {
            get
            {
                var result = new List<RowSlot>();

                RowSlot slot = new RowSlot();
                for (int i = 0; i < _slotCount; i++)
                {
                    if (_rowGrid[i] == EMPTY_SLOT)
                    {
                        if (slot.IsNew())
                            slot.Position = i;

                        slot.Size++;

                    }
                    else
                    {
                        if (!slot.IsNew())
                        {
                            result.Add(slot);
                            slot = new RowSlot();
                        }
                    }

                }

                return result;
            }
        }


        public bool TryAddServer(Server server)
        {
            var slot = AvailableSlot.FirstOrDefault(a => a.Size >= server.Size);
            if (slot != null)
            {
                server.Slot = slot.Position;
                server.Row = Index;
                server.IsUsed = true;

                for (int i = server.Slot; i < server.Slot + server.Size; i++)
                {
                    _rowGrid[i] = server.Index;
                }
            }
            else
            {
                server.IsUsed = false;
            }

            return server.IsUsed;
        }

    }
}


