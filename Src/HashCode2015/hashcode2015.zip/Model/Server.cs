﻿using QualificationTask.Model;

namespace HashCode2015.Model
{
    public class Server
    {
        

        public Server(int index, int size, int capacity)
        {
            Index = index;
            Size = size;
            Capacity = capacity;
            IsUsed = false;
        }

        public bool IsUsed { get; set; }

        public int Index { get; set; }
        public int Size { get; set; }
        public int Capacity { get; set; }

        public int Row { get; set; }
        public int Slot { get; set; }

        public Pool Pool { get; set; }

        public float Score
        {
            get { return Capacity/(float)Size; }
        }

        public override string ToString()
        {
            if(IsUsed)
                return string.Format("{0} {1} {2}", Row, Slot, Pool.Index);
            else
            {
                return "x";
            }
        }
    }
}
