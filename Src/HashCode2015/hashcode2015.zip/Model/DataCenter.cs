using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace HashCode2015.Model
{
    public class DataCenter
    {
        private IEnumerable<Server> _allServer;

        private IEnumerable<Server> _usedServers;

        private readonly List<Pool> _pools = new List<Pool>();

        private Row[] _rows;

        public DataCenter(int rowCount, int slotCount, List<Point> deadSlots, int poolCount)
        {
            //create pools
            for (int i = 0; i < poolCount; i++)
            {
                _pools.Add(new Pool(i));
            }

            _rows = new Row[rowCount];
            for (int i = 0; i < rowCount; i++)
            {
                _rows[i] = new Row(i, slotCount, deadSlots.Where(d => d.Y == i).Select(d => d.X).ToList());
            }
        }


        private static void OrganiseServerInGroup(IOrderedEnumerable<Server> serversByScoreAndSize, List<Pool> pools)
        {
            foreach (var server in serversByScoreAndSize)
            {
                var pool = pools.OrderBy(g => g.TotalCapacity).First();
                pool.Servers.Add(server);
                server.Pool = pool;
            }

            //foreach (var pool in pools)
            //{
            //    Console.WriteLine(String.Format("[{00:0}] : {1} servers and {2} capacity", pool.Index,
            //        pool.Servers.Count,
            //        pool.TotalCapacity));
            //}
        }


        public void AddServers(IEnumerable<Server> servers)
        {
            _allServer = servers;

            //sort by capacity/size
            var serversByScoreAndSize = _allServer.OrderByDescending(s => s.Score).ThenByDescending(s => s.Size);

            // put server in group to equilibrate Pool capacity
            OrganiseServerInGroup(serversByScoreAndSize, _pools);

            foreach (var server in serversByScoreAndSize)
            {
                var serverPool = server.Pool;

                var rowsOrderedForPoolCapacity = _rows.OrderBy(r => r.GetCapacityForPool(serverPool));

                foreach (var row in rowsOrderedForPoolCapacity)
                {
                    if (row.TryAddServer(server))
                        break;
                }

            }
        }

        public void DisplayGrid()
        {
            foreach (var server in _allServer)
            {
                Console.WriteLine(server);
            }
        }
    }
}