﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using HashCode2015.Model;
using QualificationTask.Model;
using TrialRound.Extentions;

namespace HashCode2015
{
    class Program
    {
        static void Main(string[] args)
        {
            const string FILE_NAME = @"Samples/dc.in";


            var rowsCount = 0;
            var slotsCount = 0;
            var slotUnavailableCount = 0;
            var poolCount = 0;
            var serversCount = 0;

            List<Point> deadSolts;
            List<Server> servers;

            deadSolts = ReadInputFile(FILE_NAME, ref rowsCount, ref slotsCount, ref poolCount, out servers);

           
          

            var datacenter = new DataCenter(rowsCount, slotsCount, deadSolts, poolCount);

            datacenter.AddServers(servers);
            

           datacenter.DisplayGrid();
            
            Debug.Print(servers.Count(server => server.IsUsed).ToString());

            Console.ReadLine();
        }

        private static List<Point> ReadInputFile(string FILE_NAME, ref int rowsCount, ref int slotsCount, ref int poolCount,
            out List<Server> servers)
        {
            int slotUnavailableCount;
            int serversCount;
            List<Point> unuvailable;
            using (var inputStream = File.OpenRead(FILE_NAME))
            {
                var reader = new StreamReader(inputStream);

                // parse first line to get Matrix Size
                var inputInt = reader.ExtractValues<int>().ToArray();

                rowsCount = inputInt[0];
                slotsCount = inputInt[1];
                slotUnavailableCount = inputInt[2];
                poolCount = inputInt[3];
                serversCount = inputInt[4];

                unuvailable =
                    Enumerable.Range(0, slotUnavailableCount)
                        .Select(_ => reader.ExtractValues<int>().ToArray())
                        .Select(x => new Point(x[1], x[0]))
                        .ToList();

                servers =
                    Enumerable.Range(0, serversCount)
                        .Select(i => new {index = i, values = reader.ExtractValues<int>().ToArray()})
                        .Select(x => new Server(x.index, x.values[0], x.values[1]))
                        .ToList();
            }
            return unuvailable;
        }
    }
}
